git add get-quote.py
git commit -m "Renamed the primary function"
git push
